module github.com/hzlnb5/codex-webgpt-guard

go 1.23
